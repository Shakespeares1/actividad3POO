package co.edu.ude.poo.eventoscongreso.crud;

import co.edu.ude.poo.eventoscongreso.dominio.Sala;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class VentanaCrudSala extends JDialog {

    private final JTextField txtId;

    private JTextField txtNombre, txtCapacidad;
    private JButton btnAgregar, btnBuscar, btnModificar, btnEliminar, btnLimpiar, btnListar;
    private static ArrayList<Sala> listaSalas = new ArrayList<>();

    public VentanaCrudSala(JFrame parent) {
        super(parent, "Formulario Sala", true);
        setSize(500, 350);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        JLabel titulo = new JLabel("Formulario Sala", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 24));
        titulo.setForeground(Color.BLUE);
        add(titulo, BorderLayout.NORTH);

        JPanel panelForm = new JPanel(new GridLayout(3, 2));
        panelForm.add(new JLabel("ID:"));
        txtId = new JTextField();
        panelForm.add(txtId);
        panelForm.add(new JLabel("Nombre:"));
        txtNombre = new JTextField();
        panelForm.add(txtNombre);
        panelForm.add(new JLabel("Capacidad:"));
        txtCapacidad = new JTextField();
        panelForm.add(txtCapacidad);
        add(panelForm, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel();
        btnAgregar = new JButton("Agregar");
        btnBuscar = new JButton("Buscar");
        btnModificar = new JButton("Modificar");
        btnEliminar = new JButton("Eliminar");
        btnLimpiar = new JButton("Limpiar");
        btnListar = new JButton("Listar");

        panelBotones.add(btnAgregar);
        panelBotones.add(btnBuscar);
        panelBotones.add(btnModificar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnLimpiar);
        panelBotones.add(btnListar);
        add(panelBotones, BorderLayout.SOUTH);

        accionesBotones();
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(false);
    }

    private void accionesBotones() {
        btnAgregar.addActionListener(e -> agregar());
        btnBuscar.addActionListener(e -> buscar());
        btnModificar.addActionListener(e -> modificar());
        btnEliminar.addActionListener(e -> eliminar());
        btnLimpiar.addActionListener(e -> limpiarCampos());
        btnListar.addActionListener(e -> listar());
    }

    private void agregar() {
        String id = txtId.getText().trim();
        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "El ID es obligatorio");
            return;
        }
        for (Sala s : listaSalas) {
            if (s.getId().equals(id)) {
                JOptionPane.showMessageDialog(this, "La sala ya existe");
                return;
            }
        }
        int confirmar = JOptionPane.showConfirmDialog(this, "¿Desea guardar?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (confirmar == JOptionPane.YES_OPTION) {
            try {
                int capacidad = Integer.parseInt(txtCapacidad.getText());
                Sala s = new Sala(id, txtNombre.getText(), capacidad);
                listaSalas.add(s);
                JOptionPane.showMessageDialog(this, "Sala guardada exitosamente");
                limpiarCampos();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Capacidad debe ser numérico");
            }
        }
    }

    private void buscar() {
        String id = txtId.getText().trim();
        for (Sala s : listaSalas) {
            if (s.getId().equals(id)) {
                txtNombre.setText(s.getNombre());
                txtCapacidad.setText(String.valueOf(s.getCapacidad()));
                btnModificar.setEnabled(true);
                btnEliminar.setEnabled(true);
                return;
            }
        }
        JOptionPane.showMessageDialog(this, "No encontrada");
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(false);
    }

    private void modificar() {
        int confirmar = JOptionPane.showConfirmDialog(this, "¿Desea modificar?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (confirmar == JOptionPane.YES_OPTION) {
            String id = txtId.getText().trim();
            for (Sala s : listaSalas) {
                if (s.getId().equals(id)) {
                    try {
                        int capacidad = Integer.parseInt(txtCapacidad.getText());
                        s.setNombre(txtNombre.getText());
                        s.setCapacidad(capacidad);
                        JOptionPane.showMessageDialog(this, "Modificada exitosamente");
                        limpiarCampos();
                        return;
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(this, "Capacidad debe ser numérico");
                    }
                }
            }
        }
    }

    private void eliminar() {
        int confirmar = JOptionPane.showConfirmDialog(this, "¿Desea eliminar?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (confirmar == JOptionPane.YES_OPTION) {
            String id = txtId.getText().trim();
            for (Sala s : listaSalas) {
                if (s.getId().equals(id)) {
                    listaSalas.remove(s);
                    JOptionPane.showMessageDialog(this, "Eliminada exitosamente");
                    limpiarCampos();
                    return;
                }
            }
        }
    }

    private void limpiarCampos() {
        txtId.setText("");
        txtNombre.setText("");
        txtCapacidad.setText("");
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(false);
    }

    private void listar() {
        if (listaSalas.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay salas registradas");
            return;
        }
        StringBuilder sb = new StringBuilder("Lista de Salas:\n");
        for (Sala s : listaSalas) {
            sb.append(s.getId()).append(" - ").append(s.getNombre()).append("\n");
        }
        JOptionPane.showMessageDialog(this, sb.toString());
    }
}
