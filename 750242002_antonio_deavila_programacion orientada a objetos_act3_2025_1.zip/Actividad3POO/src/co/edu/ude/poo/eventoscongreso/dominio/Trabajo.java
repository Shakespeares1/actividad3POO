package co.edu.ude.poo.eventoscongreso.dominio;

import java.util.List;

public class Trabajo {

    private String id;
    private String titulo;
    private String resumen;
    private String autor; // Aquí solo manejaremos un autor simple tipo String por ahora
    private List<Congresista> autores; // Se mantiene por si después amplías
    private boolean seleccionado;

    // Constructor vacío
    public Trabajo() {}

    // Constructor que pide los datos del CRUD (Actividad 3)
    public Trabajo(String id, String titulo, String autor, String resumen) {
        this.id = id;
        this.titulo = titulo;
        this.autor = autor;
        this.resumen = resumen;
    }

    // Constructor original de la actividad 2 (lo dejamos por si lo necesitas en el futuro)
    public Trabajo(String titulo, String resumen, List<Congresista> autores, boolean seleccionado) {
        this.titulo = titulo;
        this.resumen = resumen;
        this.autores = autores;
        this.seleccionado = seleccionado;
    }

    // Getters y Setters

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getResumen() { return resumen; }
    public void setResumen(String resumen) { this.resumen = resumen; }

    public String getAutor() { return autor; }
    public void setAutor(String autor) { this.autor = autor; }

    public List<Congresista> getAutores() { return autores; }
    public void setAutores(List<Congresista> autores) { this.autores = autores; }

    public boolean isSeleccionado() { return seleccionado; }
    public void setSeleccionado(boolean seleccionado) { this.seleccionado = seleccionado; }

    @Override
    public String toString() {
        return "Trabajo: " + titulo + " | " + resumen + " | Autor: " + autor + " | Seleccionado: " + seleccionado;
    }
}
