package co.edu.ude.poo.eventoscongreso.crud;

import co.edu.ude.poo.eventoscongreso.dominio.Trabajo;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

public class VentanaReporteTrabajo extends JDialog {

    private JTable tabla;
    private DefaultTableModel modeloTabla;

    public VentanaReporteTrabajo(JFrame parent, ArrayList<Trabajo> listaTrabajos) {
        super(parent, "Reporte de Trabajos", true);
        setSize(600, 400);
        setLocationRelativeTo(parent);

        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("Título");
        modeloTabla.addColumn("Resumen");
        modeloTabla.addColumn("Seleccionado");

        for (Trabajo t : listaTrabajos) {
            modeloTabla.addRow(new Object[]{
                t.getTitulo(),
                t.getResumen(),
                t.isSeleccionado() ? "Sí" : "No"
            });
        }

        tabla = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tabla);
        add(scrollPane, BorderLayout.CENTER);
    }
}
