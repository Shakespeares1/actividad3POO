package co.edu.ude.poo.eventoscongreso.principal;

import co.edu.ude.poo.eventoscongreso.crud.VentanaCrudCongresista;
import co.edu.ude.poo.eventoscongreso.crud.VentanaCrudSala;
import co.edu.ude.poo.eventoscongreso.crud.VentanaCrudSesion;
import co.edu.ude.poo.eventoscongreso.crud.VentanaCrudTrabajo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class VentanaPrincipal extends JFrame {

    private JMenuBar barraDeMenu;
    private JMenu menuCongresista, menuSala, menuSesion, menuTrabajo;

    public VentanaPrincipal() {
        setTitle("Sistema de Gestión de Eventos de Congreso");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLayout(new BorderLayout());
        setIconImage(new ImageIcon("icono.png").getImage());  // Debes tener un icono en tu proyecto

        // Imagen de fondo
        ImagePanel panelFondo = new ImagePanel("fondo.jpg");  // Debes tener la imagen fondo.jpg en tu proyecto
        setContentPane(panelFondo);

        barraDeMenu = new JMenuBar();
        crearMenus();
        setJMenuBar(barraDeMenu);
    }

    private void crearMenus() {
        menuCongresista = new JMenu("Congresista");
        menuSala = new JMenu("Sala");
        menuSesion = new JMenu("Sesion");
        menuTrabajo = new JMenu("Trabajo");

        // Menú Congresista
        JMenuItem itemAgregarCongresista = new JMenuItem("Agregar...");
        itemAgregarCongresista.addActionListener(e -> new VentanaCrudCongresista(this).setVisible(true));
        menuCongresista.add(itemAgregarCongresista);
        menuCongresista.add(new JMenuItem("Buscar..."));
        menuCongresista.add(new JMenuItem("Modificar..."));
        menuCongresista.add(new JMenuItem("Eliminar..."));
        menuCongresista.addSeparator();
        menuCongresista.add(new JMenu("Reportes..."));
        menuCongresista.add(new JMenuItem("Buscar por Institucion..."));
        menuCongresista.add(new JMenuItem("Buscar por Email..."));
        menuCongresista.add(new JMenuItem("Iniciar sesión..."));
        menuCongresista.add(new JMenuItem("Recordar password..."));
        menuCongresista.add(new JMenuItem("Cambiar Clave..."));
        menuCongresista.add(new JMenuItem("Salir..."));

        // Menú Sala
        JMenuItem itemAgregarSala = new JMenuItem("Agregar...");
        itemAgregarSala.addActionListener(e -> new VentanaCrudSala(this).setVisible(true));
        menuSala.add(itemAgregarSala);
        menuSala.add(new JMenuItem("Buscar..."));
        menuSala.add(new JMenuItem("Modificar..."));
        menuSala.add(new JMenuItem("Eliminar..."));
        menuSala.addSeparator();
        menuSala.add(new JMenu("Reportes..."));
        menuSala.add(new JMenuItem("Buscar por Nombre..."));
        menuSala.add(new JMenuItem("Buscar por Capacidad..."));

        // Menú Sesion
        JMenuItem itemAgregarSesion = new JMenuItem("Agregar...");
        itemAgregarSesion.addActionListener(e -> new VentanaCrudSesion(this).setVisible(true));
        menuSesion.add(itemAgregarSesion);
        menuSesion.add(new JMenuItem("Buscar..."));
        menuSesion.add(new JMenuItem("Modificar..."));
        menuSesion.add(new JMenuItem("Eliminar..."));
        menuSesion.addSeparator();
        menuSesion.add(new JMenu("Reportes..."));
        menuSesion.add(new JMenuItem("Buscar por Tema..."));
        menuSesion.add(new JMenuItem("Buscar por Ponente..."));

        // Menú Trabajo
        JMenuItem itemAgregarTrabajo = new JMenuItem("Agregar...");
        itemAgregarTrabajo.addActionListener(e -> new VentanaCrudTrabajo(this).setVisible(true));
        menuTrabajo.add(itemAgregarTrabajo);
        menuTrabajo.add(new JMenuItem("Buscar..."));
        menuTrabajo.add(new JMenuItem("Modificar..."));
        menuTrabajo.add(new JMenuItem("Eliminar..."));
        menuTrabajo.addSeparator();
        menuTrabajo.add(new JMenu("Reportes..."));
        menuTrabajo.add(new JMenuItem("Buscar por Título..."));
        menuTrabajo.add(new JMenuItem("Buscar por Autor..."));

        barraDeMenu.add(menuCongresista);
        barraDeMenu.add(menuSala);
        barraDeMenu.add(menuSesion);
        barraDeMenu.add(menuTrabajo);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaPrincipal().setVisible(true));
    }
}

// Clase para manejar el fondo de la ventana
class ImagePanel extends JPanel {
    private Image imagen;

    public ImagePanel(String archivoImagen) {
        try {
            imagen = new ImageIcon(archivoImagen).getImage();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (imagen != null) {
            g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
        }
    }
}
