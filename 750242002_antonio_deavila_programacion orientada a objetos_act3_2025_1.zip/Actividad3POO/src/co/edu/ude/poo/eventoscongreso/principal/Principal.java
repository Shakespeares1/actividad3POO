package co.edu.ude.poo.eventoscongreso.principal;

import co.edu.ude.poo.eventoscongreso.dominio.Congresista;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Principal {
    private static List<Congresista> congresistas = new ArrayList<>();
    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int opcion;
        do {
            System.out.println("\n MENÚ PRINCIPAL ");
            System.out.println("1. Agregar congresista");
            System.out.println("2. Listar congresistas");
            System.out.println("3. Buscar congresista por nombre");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = Integer.parseInt(sc.nextLine());

            switch (opcion) {
                case 1:
                    agregarCongresista();
                    break;
                case 2:
                    listarCongresistas();
                    break;
                case 3:
                    buscarCongresista();
                    break;
                case 4:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción no válida");
            }
        } while (opcion != 4);
    }

    private static void agregarCongresista() {
        System.out.print("Nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Apellido: ");
        String apellido = sc.nextLine();
        System.out.print("Institución: ");
        String institucion = sc.nextLine();
        System.out.print("Correo: ");
        String correo = sc.nextLine();
        System.out.print("Teléfono: ");
        String telefono = sc.nextLine();

        Congresista c = new Congresista(nombre, apellido, institucion, correo, telefono);
        congresistas.add(c);
        System.out.println("✅ Congresista agregado.");
    }

    private static void listarCongresistas() {
        if (congresistas.isEmpty()) {
            System.out.println("⚠ No hay congresistas registrados.");
        } else {
            for (Congresista c : congresistas) {
                System.out.println(c);
            }
        }
    }

    private static void buscarCongresista() {
        System.out.print("Ingrese el nombre del congresista: ");
        String nombre = sc.nextLine();
        boolean encontrado = false;
        for (Congresista c : congresistas) {
            if (c.getNombre().equalsIgnoreCase(nombre)) {
                System.out.println("🔎 Encontrado: " + c);
                encontrado = true;
                break;
            }
        }
        if (!encontrado) {
            System.out.println("❌ No se encontró el congresista.");
        }
    }
}
