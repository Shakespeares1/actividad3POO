package co.edu.ude.poo.eventoscongreso.crud;

import co.edu.ude.poo.eventoscongreso.dominio.Congresista;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

public class VentanaReporteCongresista extends JDialog {

    private JTable tabla;
    private DefaultTableModel modeloTabla;

    public VentanaReporteCongresista(JFrame parent, ArrayList<Congresista> listaCongresistas) {
        super(parent, "Reporte de Congresistas", true);
        setSize(600, 400);
        setLocationRelativeTo(parent);

        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("ID");
        modeloTabla.addColumn("Nombre");
        modeloTabla.addColumn("Email");
        modeloTabla.addColumn("Teléfono");
        modeloTabla.addColumn("Institución");

        for (Congresista c : listaCongresistas) {
            modeloTabla.addRow(new Object[]{
                c.getId(),
                c.getNombre(),
                c.getEmail(),
                c.getTelefono(),
                c.getInstitucion()
            });
        }

        tabla = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tabla);
        add(scrollPane, BorderLayout.CENTER);
    }
}

