package co.edu.ude.poo.eventoscongreso.crud;

import co.edu.ude.poo.eventoscongreso.dominio.Trabajo;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class VentanaCrudTrabajo extends JDialog {

    private JTextField txtId, txtTitulo, txtAutor, txtResumen;
    private JButton btnAgregar, btnBuscar, btnModificar, btnEliminar, btnLimpiar, btnListar;
    private static ArrayList<Trabajo> listaTrabajos = new ArrayList<>();

    public VentanaCrudTrabajo(JFrame parent) {
        super(parent, "Formulario Trabajo", true);
        setSize(500, 400);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        JLabel titulo = new JLabel("Formulario Trabajo", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 24));
        titulo.setForeground(Color.BLUE);
        add(titulo, BorderLayout.NORTH);

        JPanel panelForm = new JPanel(new GridLayout(4, 2));
        panelForm.add(new JLabel("ID:"));
        txtId = new JTextField();
        panelForm.add(txtId);
        panelForm.add(new JLabel("Título:"));
        txtTitulo = new JTextField();
        panelForm.add(txtTitulo);
        panelForm.add(new JLabel("Autor:"));
        txtAutor = new JTextField();
        panelForm.add(txtAutor);
        panelForm.add(new JLabel("Resumen:"));
        txtResumen = new JTextField();
        panelForm.add(txtResumen);
        add(panelForm, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel();
        btnAgregar = new JButton("Agregar");
        btnBuscar = new JButton("Buscar");
        btnModificar = new JButton("Modificar");
        btnEliminar = new JButton("Eliminar");
        btnLimpiar = new JButton("Limpiar");
        btnListar = new JButton("Listar");

        panelBotones.add(btnAgregar);
        panelBotones.add(btnBuscar);
        panelBotones.add(btnModificar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnLimpiar);
        panelBotones.add(btnListar);
        add(panelBotones, BorderLayout.SOUTH);

        accionesBotones();
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(false);
    }

    private void accionesBotones() {
        btnAgregar.addActionListener(e -> agregar());
        btnBuscar.addActionListener(e -> buscar());
        btnModificar.addActionListener(e -> modificar());
        btnEliminar.addActionListener(e -> eliminar());
        btnLimpiar.addActionListener(e -> limpiarCampos());
        btnListar.addActionListener(e -> listar());
    }

    private void agregar() {
        String id = txtId.getText().trim();
        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "El ID es obligatorio");
            return;
        }
        for (Trabajo t : listaTrabajos) {
            if (t.getId().equals(id)) {
                JOptionPane.showMessageDialog(this, "El trabajo ya existe");
                return;
            }
        }
        int confirmar = JOptionPane.showConfirmDialog(this, "¿Desea guardar?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (confirmar == JOptionPane.YES_OPTION) {
            Trabajo t = new Trabajo(id, txtTitulo.getText(), txtAutor.getText(), txtResumen.getText());
            listaTrabajos.add(t);
            JOptionPane.showMessageDialog(this, "Trabajo guardado exitosamente");
            limpiarCampos();
        }
    }

    private void buscar() {
        String id = txtId.getText().trim();
        for (Trabajo t : listaTrabajos) {
            if (t.getId().equals(id)) {
                txtTitulo.setText(t.getTitulo());
                txtAutor.setText(t.getAutor());
                txtResumen.setText(t.getResumen());
                btnModificar.setEnabled(true);
                btnEliminar.setEnabled(true);
                return;
            }
        }
        JOptionPane.showMessageDialog(this, "No encontrado");
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(false);
    }

    private void modificar() {
        int confirmar = JOptionPane.showConfirmDialog(this, "¿Desea modificar?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (confirmar == JOptionPane.YES_OPTION) {
            String id = txtId.getText().trim();
            for (Trabajo t : listaTrabajos) {
                if (t.getId().equals(id)) {
                    t.setTitulo(txtTitulo.getText());
                    t.setAutor(txtAutor.getText());
                    t.setResumen(txtResumen.getText());
                    JOptionPane.showMessageDialog(this, "Modificado exitosamente");
                    limpiarCampos();
                    return;
                }
            }
        }
    }

    private void eliminar() {
        int confirmar = JOptionPane.showConfirmDialog(this, "¿Desea eliminar?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (confirmar == JOptionPane.YES_OPTION) {
            String id = txtId.getText().trim();
            for (Trabajo t : listaTrabajos) {
                if (t.getId().equals(id)) {
                    listaTrabajos.remove(t);
                    JOptionPane.showMessageDialog(this, "Eliminado exitosamente");
                    limpiarCampos();
                    return;
                }
            }
        }
    }

    private void limpiarCampos() {
        txtId.setText("");
        txtTitulo.setText("");
        txtAutor.setText("");
        txtResumen.setText("");
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(false);
    }

    private void listar() {
        if (listaTrabajos.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay trabajos registrados");
            return;
        }
        StringBuilder sb = new StringBuilder("Lista de Trabajos:\n");
        for (Trabajo t : listaTrabajos) {
            sb.append(t.getId()).append(" - ").append(t.getTitulo()).append("\n");
        }
        JOptionPane.showMessageDialog(this, sb.toString());
    }
}
