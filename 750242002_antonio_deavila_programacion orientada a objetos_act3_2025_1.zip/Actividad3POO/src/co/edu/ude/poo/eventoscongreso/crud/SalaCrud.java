package co.edu.ude.poo.eventoscongreso.crud;

import co.edu.ude.poo.eventoscongreso.dominio.Sala;
import java.util.ArrayList;
import java.util.List;

public class SalaCrud {
    private static List<Sala> lista = new ArrayList<>();

    public static void agregar(Sala sala) throws Exception {
        for (Sala s : lista) {
            if (s.getNombre().equalsIgnoreCase(sala.getNombre())) {
                throw new Exception("⚠ Ya existe una sala con ese nombre.");
            }
        }
        lista.add(sala);
    }

    public static Sala buscarPorNombre(String nombre) throws Exception {
        for (Sala s : lista) {
            if (s.getNombre().equalsIgnoreCase(nombre)) {
                return s;
            }
        }
        throw new Exception("❌ No se encontró sala con ese nombre.");
    }

    public static void editar(Sala salaActualizada) throws Exception {
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getNombre().equalsIgnoreCase(salaActualizada.getNombre())) {
                lista.set(i, salaActualizada);
                return;
            }
        }
        throw new Exception("❌ No se encontró sala a editar.");
    }

    public static void eliminar(String nombre) throws Exception {
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getNombre().equalsIgnoreCase(nombre)) {
                lista.remove(i);
                return;
            }
        }
        throw new Exception("❌ No se encontró sala a eliminar.");
    }

    public static List<Sala> listarTodo() {
        return lista;
    }

    public static int contar() {
        return lista.size();
    }
}

