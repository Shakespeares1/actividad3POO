package co.edu.ude.poo.eventoscongreso.crud;

import co.edu.ude.poo.eventoscongreso.dominio.Sesion;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

public class VentanaReporteSesion extends JDialog {

    private JTable tabla;
    private DefaultTableModel modeloTabla;

    public VentanaReporteSesion(JFrame parent, ArrayList<Sesion> listaSesiones) {
        super(parent, "Reporte de Sesiones", true);
        setSize(600, 400);
        setLocationRelativeTo(parent);

        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("ID");
        modeloTabla.addColumn("Tema");
        modeloTabla.addColumn("Ponente");
        modeloTabla.addColumn("Horario");

        for (Sesion s : listaSesiones) {
            modeloTabla.addRow(new Object[]{
                s.getId(),
                s.getTema(),
                s.getPonente(),
                s.getHorario()
            });
        }

        tabla = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tabla);
        add(scrollPane, BorderLayout.CENTER);
    }
}
