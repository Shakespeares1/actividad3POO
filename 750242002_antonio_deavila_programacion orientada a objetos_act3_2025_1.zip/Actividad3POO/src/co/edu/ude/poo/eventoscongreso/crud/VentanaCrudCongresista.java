package co.edu.ude.poo.eventoscongreso.crud;

import co.edu.ude.poo.eventoscongreso.dominio.Congresista;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class VentanaCrudCongresista extends JDialog {

    private final JTextField txtId;
    private final JTextField txtNombre;
    private final JTextField txtEmail;

    private final JTextField txtTelefono;
    private final JTextField txtInstitucion;
    private final JButton btnAgregar;
    private JButton btnBuscar, btnModificar, btnEliminar, btnLimpiar, btnListar;
    private static ArrayList<Congresista> listaCongresistas = new ArrayList<>();

    public VentanaCrudCongresista(JFrame parent) {
        super(parent, "Formulario Congresista", true);
        setSize(600, 400);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        JLabel titulo = new JLabel("Formulario Congresista", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 24));
        titulo.setForeground(Color.BLUE);
        add(titulo, BorderLayout.NORTH);

        JPanel panelForm = new JPanel(new GridLayout(5, 2));
        panelForm.add(new JLabel("ID:"));
        txtId = new JTextField();
        panelForm.add(txtId);
        panelForm.add(new JLabel("Nombre:"));
        txtNombre = new JTextField();
        panelForm.add(txtNombre);
        panelForm.add(new JLabel("Email:"));
        txtEmail = new JTextField();
        panelForm.add(txtEmail);
        panelForm.add(new JLabel("Teléfono:"));
        txtTelefono = new JTextField();
        panelForm.add(txtTelefono);
        panelForm.add(new JLabel("Institución:"));
        txtInstitucion = new JTextField();
        panelForm.add(txtInstitucion);
        add(panelForm, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel();
        btnAgregar = new JButton("Agregar", new ImageIcon("src/imagenes/Agregar.png"));
        btnBuscar = new JButton("Buscar", new ImageIcon("src/imagenes/Buscar.png"));
        btnModificar = new JButton("Modificar", new ImageIcon("src/imagenes/Modificar.png"));
        btnEliminar = new JButton("Eliminar", new ImageIcon("src/imagenes/Eliminar.png"));
        btnLimpiar = new JButton("Limpiar", new ImageIcon("src/imagenes/Limpiar.png"));
        btnListar = new JButton("Listar", new ImageIcon("src/imagenes/Listar.png"));


        panelBotones.add(btnAgregar);
        panelBotones.add(btnBuscar);
        panelBotones.add(btnModificar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnLimpiar);
        panelBotones.add(btnListar);
        add(panelBotones, BorderLayout.SOUTH);

        accionesBotones();
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(false);
    }

    private void accionesBotones() {
        btnAgregar.addActionListener(e -> agregar());
        btnBuscar.addActionListener(e -> buscar());
        btnModificar.addActionListener(e -> modificar());
        btnEliminar.addActionListener(e -> eliminar());
        btnLimpiar.addActionListener(e -> limpiarCampos());
        btnListar.addActionListener(e -> listar());
    }

    private void agregar() {
        String id = txtId.getText().trim();
        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "El ID es obligatorio");
            return;
        }
        for (Congresista c : listaCongresistas) {
            if (c.getId().equals(id)) {
                JOptionPane.showMessageDialog(this, "El congresista ya existe");
                return;
            }
        }
        int confirmar = JOptionPane.showConfirmDialog(this, "¿Desea guardar?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (confirmar == JOptionPane.YES_OPTION) {
            Congresista c = new Congresista(id, txtNombre.getText(), txtEmail.getText(), txtTelefono.getText(), txtInstitucion.getText());
            listaCongresistas.add(c);
            JOptionPane.showMessageDialog(this, "Congresista guardado exitosamente");
            limpiarCampos();
        }
    }

    private void buscar() {
        String id = txtId.getText().trim();
        for (Congresista c : listaCongresistas) {
            if (c.getId().equals(id)) {
                txtNombre.setText(c.getNombre());
                txtEmail.setText(c.getEmail());
                txtTelefono.setText(c.getTelefono());
                txtInstitucion.setText(c.getInstitucion());
                btnModificar.setEnabled(true);
                btnEliminar.setEnabled(true);
                return;
            }
        }
        JOptionPane.showMessageDialog(this, "No encontrado");
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(false);
    }

    private void modificar() {
        int confirmar = JOptionPane.showConfirmDialog(this, "¿Desea modificar?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (confirmar == JOptionPane.YES_OPTION) {
            String id = txtId.getText().trim();
            for (Congresista c : listaCongresistas) {
                if (c.getId().equals(id)) {
                    c.setNombre(txtNombre.getText());
                    c.setEmail(txtEmail.getText());
                    c.setTelefono(txtTelefono.getText());
                    c.setInstitucion(txtInstitucion.getText());
                    JOptionPane.showMessageDialog(this, "Modificado exitosamente");
                    limpiarCampos();
                    return;
                }
            }
        }
    }

    private void eliminar() {
        int confirmar = JOptionPane.showConfirmDialog(this, "¿Desea eliminar?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (confirmar == JOptionPane.YES_OPTION) {
            String id = txtId.getText().trim();
            for (Congresista c : listaCongresistas) {
                if (c.getId().equals(id)) {
                    listaCongresistas.remove(c);
                    JOptionPane.showMessageDialog(this, "Eliminado exitosamente");
                    limpiarCampos();
                    return;
                }
            }
        }
    }

    private void limpiarCampos() {
        txtId.setText("");
        txtNombre.setText("");
        txtEmail.setText("");
        txtTelefono.setText("");
        txtInstitucion.setText("");
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(false);
    }

    private void listar() {
        if (listaCongresistas.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay congresistas registrados");
            return;
        }
        StringBuilder sb = new StringBuilder("Lista de Congresistas:\n");
        for (Congresista c : listaCongresistas) {
            sb.append(c.getId()).append(" - ").append(c.getNombre()).append("\n");
        }
        JOptionPane.showMessageDialog(this, sb.toString());
    }
}

