package co.edu.ude.poo.eventoscongreso.crud;

import co.edu.ude.poo.eventoscongreso.dominio.Sala;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

public class VentanaReporteSala extends JDialog {

    private JTable tabla;
    private DefaultTableModel modeloTabla;

    public VentanaReporteSala(JFrame parent, ArrayList<Sala> listaSalas) {
        super(parent, "Reporte de Salas", true);
        setSize(600, 400);
        setLocationRelativeTo(parent);

        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("ID");
        modeloTabla.addColumn("Nombre");
        modeloTabla.addColumn("Capacidad");

        for (Sala s : listaSalas) {
            modeloTabla.addRow(new Object[]{
                s.getId(),
                s.getNombre(),
                s.getCapacidad()
            });
        }

        tabla = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tabla);
        add(scrollPane, BorderLayout.CENTER);
    }
}

