package co.edu.ude.poo.eventoscongreso.crud;

import co.edu.ude.poo.eventoscongreso.dominio.Sesion;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class VentanaCrudSesion extends JDialog {

    private JTextField txtId, txtTema, txtPonente, txtHorario;
    private JButton btnAgregar, btnBuscar, btnModificar, btnEliminar, btnLimpiar, btnListar;
    private static ArrayList<Sesion> listaSesiones = new ArrayList<>();

    public VentanaCrudSesion(JFrame parent) {
        super(parent, "Formulario Sesion", true);
        setSize(500, 400);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        JLabel titulo = new JLabel("Formulario Sesion", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 24));
        titulo.setForeground(Color.BLUE);
        add(titulo, BorderLayout.NORTH);

        JPanel panelForm = new JPanel(new GridLayout(4, 2));
        panelForm.add(new JLabel("ID:"));
        txtId = new JTextField();
        panelForm.add(txtId);
        panelForm.add(new JLabel("Tema:"));
        txtTema = new JTextField();
        panelForm.add(txtTema);
        panelForm.add(new JLabel("Ponente:"));
        txtPonente = new JTextField();
        panelForm.add(txtPonente);
        panelForm.add(new JLabel("Horario:"));
        txtHorario = new JTextField();
        panelForm.add(txtHorario);
        add(panelForm, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel();
        btnAgregar = new JButton("Agregar");
        btnBuscar = new JButton("Buscar");
        btnModificar = new JButton("Modificar");
        btnEliminar = new JButton("Eliminar");
        btnLimpiar = new JButton("Limpiar");
        btnListar = new JButton("Listar");

        panelBotones.add(btnAgregar);
        panelBotones.add(btnBuscar);
        panelBotones.add(btnModificar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnLimpiar);
        panelBotones.add(btnListar);
        add(panelBotones, BorderLayout.SOUTH);

        accionesBotones();
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(false);
    }

    private void accionesBotones() {
        btnAgregar.addActionListener(e -> agregar());
        btnBuscar.addActionListener(e -> buscar());
        btnModificar.addActionListener(e -> modificar());
        btnEliminar.addActionListener(e -> eliminar());
        btnLimpiar.addActionListener(e -> limpiarCampos());
        btnListar.addActionListener(e -> listar());
    }

    private void agregar() {
        String id = txtId.getText().trim();
        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "El ID es obligatorio");
            return;
        }
        for (Sesion s : listaSesiones) {
            if (s.getId().equals(id)) {
                JOptionPane.showMessageDialog(this, "La sesión ya existe");
                return;
            }
        }
        int confirmar = JOptionPane.showConfirmDialog(this, "¿Desea guardar?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (confirmar == JOptionPane.YES_OPTION) {
            Sesion s = new Sesion(id, txtTema.getText(), txtPonente.getText(), txtHorario.getText());
            listaSesiones.add(s);
            JOptionPane.showMessageDialog(this, "Sesión guardada exitosamente");
            limpiarCampos();
        }
    }

    private void buscar() {
        String id = txtId.getText().trim();
        for (Sesion s : listaSesiones) {
            if (s.getId().equals(id)) {
                txtTema.setText(s.getTema());
                txtPonente.setText(s.getPonente());
                txtHorario.setText(s.getHorario());
                btnModificar.setEnabled(true);
                btnEliminar.setEnabled(true);
                return;
            }
        }
        JOptionPane.showMessageDialog(this, "No encontrada");
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(false);
    }

    private void modificar() {
        int confirmar = JOptionPane.showConfirmDialog(this, "¿Desea modificar?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (confirmar == JOptionPane.YES_OPTION) {
            String id = txtId.getText().trim();
            for (Sesion s : listaSesiones) {
                if (s.getId().equals(id)) {
                    s.setTema(txtTema.getText());
                    s.setPonente(txtPonente.getText());
                    s.setHorario(txtHorario.getText());
                    JOptionPane.showMessageDialog(this, "Modificada exitosamente");
                    limpiarCampos();
                    return;
                }
            }
        }
    }

    private void eliminar() {
        int confirmar = JOptionPane.showConfirmDialog(this, "¿Desea eliminar?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (confirmar == JOptionPane.YES_OPTION) {
            String id = txtId.getText().trim();
            for (Sesion s : listaSesiones) {
                if (s.getId().equals(id)) {
                    listaSesiones.remove(s);
                    JOptionPane.showMessageDialog(this, "Eliminada exitosamente");
                    limpiarCampos();
                    return;
                }
            }
        }
    }

    private void limpiarCampos() {
        txtId.setText("");
        txtTema.setText("");
        txtPonente.setText("");
        txtHorario.setText("");
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(false);
    }

    private void listar() {
        if (listaSesiones.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay sesiones registradas");
            return;
        }
        StringBuilder sb = new StringBuilder("Lista de Sesiones:\n");
        for (Sesion s : listaSesiones) {
            sb.append(s.getId()).append(" - ").append(s.getTema()).append("\n");
        }
        JOptionPane.showMessageDialog(this, sb.toString());
    }
}

